"use strict";
// Minimal MV3 service worker — no logic needed, popup handles everything
